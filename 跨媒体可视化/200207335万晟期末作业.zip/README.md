# A_star
1. 利用tkinter实现了gui，可利用鼠标自己选定起始点、终止点和障碍物；
2. h值的计算利用了欧氏距离；
3. 代码详细介绍请参见introduction。

