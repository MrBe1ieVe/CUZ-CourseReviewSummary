package com.drunkbaby.ctfplatform.service.impl;

import com.drunkbaby.ctfplatform.mapper.SolveMapper;
import com.drunkbaby.ctfplatform.mapper.UserMapper;
import com.drunkbaby.ctfplatform.pojo.User;
import com.drunkbaby.ctfplatform.service.UserService;
import com.drunkbaby.ctfplatform.utils.TypeChallengeResultHandler;
import org.apache.ibatis.session.ResultHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service(value = "UserService")
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private SolveMapper solveMapper;
    /**
     *
     * @param id
     * @return 完整的user信息，包括其各种类型的题目的解题情况
     */
    @Override
    public User getUserById(Integer id) {
        User user=userMapper.getUserById(id);
        ResultHandler resultHandler=new TypeChallengeResultHandler();
        solveMapper.listTypeGroupSolvedByUserId(id,resultHandler);
        Map<Integer, List<Integer>> typeSolvedChallenges=((TypeChallengeResultHandler) resultHandler).getResults();
        user.setSolvedChallenge(typeSolvedChallenges);
        return user;
    }

    /**
     * @param user 插入的用户
     * @return 改变的行数
     */
    @Override
    public Integer insertUser(User user) {
        return userMapper.insertUser(user);
    }

    @Override
    public Integer getUserNumber() {
        return userMapper.SelectUserNumber();
    }




}
