package com.drunkbaby.ctfplatform.service.impl;


import com.drunkbaby.ctfplatform.mapper.ChallengeMapper;
import com.drunkbaby.ctfplatform.mapper.SolveMapper;
import com.drunkbaby.ctfplatform.pojo.Challenge;
import com.drunkbaby.ctfplatform.pojo.User;
import com.drunkbaby.ctfplatform.service.SolveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value = "SolveService")
public class SolveServiceImpl implements SolveService {

    @Autowired
    private ChallengeMapper challengeMapper;
    @Autowired
    private SolveMapper solveMapper;


    @Override
    public void saveNewSolved(Challenge challenge, User user) {
        solveMapper.insertNewSolve(challenge.getCid(),user.getUid());
    }

    @Override
    public int addOneSolvedNumber(int cid) {
       return solveMapper.addOneSolvedNumber(cid);
    }

    @Override
    public int addOneUserSolvedNumber(int uid) {
        return solveMapper.addOneUserSolvedNumber(uid);
    }
}

