package com.drunkbaby.ctfplatform.service;



import com.drunkbaby.ctfplatform.pojo.Notice;

import java.util.List;

public interface NoticeService {
     int saveNotice(String description);
     int deleteNotice(int nid);
      List<Notice> getNoticeList();

}
