package com.drunkbaby.ctfplatform.service;


import com.drunkbaby.ctfplatform.pojo.Challenge;
import com.drunkbaby.ctfplatform.pojo.ChallengeList;

public interface ChallengeService {
    ChallengeList listAllChallenges();
    Challenge getChallengeById(int cid);
    int saveChallenge(Challenge challenge);
    void deleteChallenge(int cid);
    int addChallenge(Challenge challenge);

}
