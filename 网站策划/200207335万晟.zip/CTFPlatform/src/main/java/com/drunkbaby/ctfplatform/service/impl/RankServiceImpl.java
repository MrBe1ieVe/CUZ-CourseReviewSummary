package com.drunkbaby.ctfplatform.service.impl;

import com.drunkbaby.ctfplatform.mapper.ChallengeMapper;
import com.drunkbaby.ctfplatform.mapper.RankMapper;
import com.drunkbaby.ctfplatform.mapper.UserMapper;
import com.drunkbaby.ctfplatform.pojo.RankList;
import com.drunkbaby.ctfplatform.pojo.User;
import com.drunkbaby.ctfplatform.service.RankService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service(value = "RankService")
public class RankServiceImpl implements RankService {
    private static final Logger log= LoggerFactory.getLogger(RankServiceImpl.class);
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private RankMapper rankMapper;
    @Autowired
    private ChallengeMapper challengeMapper;
    @Override
    public int getUserRankByUid(int uid) {
        Integer solvedNumber=userMapper.getUserSolvedNumberById(uid);
        RankList[] countUserNumberOfSolvedNumberList=rankMapper.countUserNumberOfSolvedNumber();
        int countAmountUser=0;
        for (RankList rankList : countUserNumberOfSolvedNumberList) {
            if (rankList.getSolvedNumber()<=solvedNumber){
                break;
            }
            else {
                countAmountUser=+rankList.getUserNumber();
            }
        }
        return countAmountUser+1;
    }

    @Override
    public List<User> getUserRankList() {
        return userMapper.listUsersDescOrderBySolvedNumber();
    }
}
