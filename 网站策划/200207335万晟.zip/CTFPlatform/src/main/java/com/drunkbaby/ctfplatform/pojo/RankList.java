package com.drunkbaby.ctfplatform.pojo;

public class RankList {
    private Integer solvedNumber;
    private Integer userNumber;

    public Integer getSolvedNumber() {
        return solvedNumber;
    }

    public void setSolvedNumber(Integer solvedNumber) {
        this.solvedNumber = solvedNumber;
    }

    public Integer getUserNumber() {
        return userNumber;
    }

    public void setUserNumber(Integer userNumber) {
        this.userNumber = userNumber;
    }
}
