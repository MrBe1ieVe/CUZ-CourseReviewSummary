package com.drunkbaby.ctfplatform.service;


import com.drunkbaby.ctfplatform.pojo.User;

public interface UserService {
    User getUserById(Integer id);
    Integer insertUser(User user);
    Integer getUserNumber();

}
