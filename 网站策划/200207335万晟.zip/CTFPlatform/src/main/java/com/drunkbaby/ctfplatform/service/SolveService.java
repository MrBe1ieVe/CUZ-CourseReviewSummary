package com.drunkbaby.ctfplatform.service;


import com.drunkbaby.ctfplatform.pojo.Challenge;
import com.drunkbaby.ctfplatform.pojo.User;

public interface SolveService {
     void saveNewSolved(Challenge challenge, User user);
     int addOneSolvedNumber(int cid);
     int addOneUserSolvedNumber(int uid);
}
