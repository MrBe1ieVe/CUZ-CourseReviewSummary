package com.drunkbaby.ctfplatform.service;

import com.drunkbaby.ctfplatform.pojo.User;

import java.util.List;

public interface RankService {
    List<User> getUserRankList();
    int getUserRankByUid(int uid);
}
