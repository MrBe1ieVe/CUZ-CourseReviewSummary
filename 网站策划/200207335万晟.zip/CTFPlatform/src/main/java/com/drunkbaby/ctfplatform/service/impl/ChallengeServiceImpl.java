package com.drunkbaby.ctfplatform.service.impl;


import com.drunkbaby.ctfplatform.mapper.ChallengeMapper;
import com.drunkbaby.ctfplatform.mapper.SolveMapper;
import com.drunkbaby.ctfplatform.mapper.UserMapper;
import com.drunkbaby.ctfplatform.pojo.Challenge;
import com.drunkbaby.ctfplatform.pojo.ChallengeList;
import com.drunkbaby.ctfplatform.pojo.ChallengeType;
import com.drunkbaby.ctfplatform.service.ChallengeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("ChallengeService")
public class ChallengeServiceImpl implements ChallengeService {
    @Autowired
    @Lazy
    private ChallengeMapper challengeMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private SolveMapper solveMapper;
    @Autowired
    @Lazy
    private ChallengeService challengeService;
    @Override
    public ChallengeList listAllChallenges() {
        ChallengeList challengeList = ChallengeList.getInstance();
        for (ChallengeType value : ChallengeType.values()) {
            challengeList.getChallengeListMap().put(value.getTypecode(), challengeMapper.listChallengesByType(value.getTypecode()));
        }
        return challengeList;
    }

    @Override
    public Challenge getChallengeById(int cid) {
        return challengeMapper.getChallengeById(cid);
    }

    @Override
    public int saveChallenge(Challenge challenge) {
       return challengeMapper.updateChallenge(challenge);
    }

    /**
     * @param cid 需要删除的题目，删除之后，需要将题目从TypeChallengeMap中移除
     * 从数据库移除相关题目信息，将做过这道题的人的solvedNumber-1;
     *由于排名界面是视图，所以不需要更改rankview
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteChallenge(int cid) {
        Challenge challengeWantToDelete=challengeMapper.getChallengeById(cid);
        challengeMapper.deleteChallengeById(cid);
        challengeService.listAllChallenges().getChallengeListMap().get(challengeWantToDelete.getType()).remove(challengeWantToDelete);
        userMapper.updateSolvedNumberCauseByChallengeDelete(cid);
        solveMapper.deleteSolvedByCid(cid);
    }

    @Override
    public int addChallenge(Challenge challenge) {
        challengeService.listAllChallenges().getChallengeListMap().get(challenge.getType()).add(challenge);
        return challengeMapper.insertChallenge(challenge);

    }
}
