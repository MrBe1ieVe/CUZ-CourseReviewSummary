package com.drunkbaby.ctfplatform.mapper;

import com.drunkbaby.ctfplatform.pojo.Notice;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface NoticeMapper {
    /**
     * @return 返回按时间排序后的通知列表（最新的排在最前面）
     */
    @Select("SELECT nid,date,description FROM notice ORDER BY date DESC")
    public List<Notice> listAllNotices();
    @Insert("INSERT INTO notice(date,description) values (CURRENT_TIME,#{description})")
    public int insertNotice(String description);
    @Delete("Delete  from notice where nid=#{nid}")
    public  int deleteNotice(int nid);
}
