package com.drunkbaby.ctfplatform.service.impl;


import com.drunkbaby.ctfplatform.mapper.NoticeMapper;
import com.drunkbaby.ctfplatform.pojo.Notice;
import com.drunkbaby.ctfplatform.service.NoticeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("NoticeService")
public class NoticeServiceImpl implements NoticeService {
    @Autowired
    private NoticeMapper noticeMapper;
    @Override
    public int saveNotice(String description) {
        return noticeMapper.insertNotice(description);
    }
    @Override
    public int deleteNotice(int nid) {
        return noticeMapper.deleteNotice(nid);
    }
    @Override
    public List<Notice> getNoticeList() {
        return noticeMapper.listAllNotices();
    }
}
