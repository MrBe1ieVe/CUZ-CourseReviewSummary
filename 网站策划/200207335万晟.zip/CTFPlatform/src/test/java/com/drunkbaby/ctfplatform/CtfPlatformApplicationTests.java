package com.drunkbaby.ctfplatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CtfPlatformApplicationTests {

    @Test
    void contextLoads() {
    }

}
