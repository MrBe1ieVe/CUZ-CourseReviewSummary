# 运行说明



先导入 .sql 文件，run 即可。

![](/images/sql.png)

运行，访问 localhost:8083，index 界面如下

![](/images/index.png)



![](/images/index2.png)

登录界面

![](/images/login.png)

此处采用 shiro 做鉴权，以 admin 登录后，管理界面如图

![](/images/manager.png)

